<?php
/**
 * Plugin Name:       Philosophy-Companion
 * Plugin URI:
 * Description:       Companion plugin for the philosophy theme
 * Version:           1.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Mahmudul Hassan
 * Author URI:        https://mahmudulhassan.me/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       philosophy_companion
 * Domain Path:       /languages
 */

function philosophy_companion_register_my_cpts_book() {

	/**
	 * Post Type: Books.
	 */

	$labels = array(
		'name'           => __( 'Books', 'philosophy' ),
		'singular_name'  => __( 'Book', 'philosophy' ),
		'menu_name'      => __( 'My Books', 'philosophy' ),
		'featured_image' => __( 'Book Cover', 'philosophy' ),
	);

	$args = array(
		'label'                 => __( 'Books', 'philosophy' ),
		'labels'                => $labels,
		'description'           => '',
		'public'                => true,
		'publicly_queryable'    => true,
		'show_ui'               => true,
		'show_in_rest'          => true,
		'rest_base'             => '',
		'rest_controller_class' => 'WP_REST_Posts_Controller',
		'has_archive'           => 'books',
		'show_in_menu'          => true,
		'show_in_nav_menus'     => true,
		'delete_with_user'      => false,
		'exclude_from_search'   => false,
		'capability_type'       => 'post',
		'map_meta_cap'          => true,
		'hierarchical'          => false,
		'rewrite'               => array(
			'slug'       => 'book',
			'with_front' => false,
		),
		'query_var'             => true,
		'menu_icon'             => 'dashicons-book-alt',
		'supports'              => array( 'title', 'editor', 'thumbnail', 'excerpt', 'author' ),
		'taxonomies'            => array( 'category' ),
	);

	register_post_type( 'book', $args );
}

add_action( 'init', 'philosophy_companion_register_my_cpts_book' );

